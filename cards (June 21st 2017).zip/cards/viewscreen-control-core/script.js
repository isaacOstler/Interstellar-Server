var ViewscreenControlCore_CurrentCard = 0;
var ViewscreenControlCore_TaticalMaster;

onDatabaseValueChange("viewscreen.tacticalMaster",function(newData){
	if(newData == null){
		return;
	}
	interstellarSay("New viewscreen tactical, " + newData.tacticalName);
	ViewscreenControlCore_TaticalMaster = newData;
	$("#Viewscreen-Control-Core_taticalNameTextbox").val(newData.tacticalName);
});

function ViewscreenControlCore_drawCardsList(){
	var html = "";
	for(var i = 0; i < ViewscreenControlCore_TaticalMaster.cards.length;i++){
		if(ViewscreenControlCore_CurrentCard == i){
			html += "<div id='cardsViewscreenListNumber" + i + "' class='Viewscreen-Control-Core_CardsListCard'  style='background-color:red'>" + ViewscreenControlCore_TaticalMaster.cards[i].cardName + "</div>";
		}else{
			html += "<div id='cardsViewscreenListNumber" + i + "' class='Viewscreen-Control-Core_CardsListCard'>" + ViewscreenControlCore_TaticalMaster.cards[i].cardName + "</div>";
		}
	}
	$("#Viewscreen-Control-Core_CardsList").html(html);
	setTimeout(function(){
		$("#Viewscreen-Control-Core_CardsList").animate({scrollTop : $("#cardsViewscreenListNumber" + ViewscreenControlCore_CurrentCard).position().top});
	},0010);
}

$("#Viewscreen-Control-Core_nextCardButton").click(function(event){
	ViewscreenControlCore_CurrentCard++;
	setDatabaseValue("viewscreen.forceToTacticalCard",ViewscreenControlCore_CurrentCard);
})
$("#Viewscreen-Control-Core_lastCardButton").click(function(event){
	ViewscreenControlCore_CurrentCard--;
	if(ViewscreenControlCore_CurrentCard == -1){
		ViewscreenControlCore_CurrentCard = ViewscreenControlCore_TaticalMaster.cards.length - 1;
	}
	setDatabaseValue("viewscreen.forceToTacticalCard",ViewscreenControlCore_CurrentCard);
})

onDatabaseValueChange("viewscreen.currentCard",function(newData){
	if(newData == null){
		return;
	}
	ViewscreenControlCore_CurrentCard = newData;
	$("#Viewscreen-Control-Core_currentCardTextbox").val(newData + 1);
	ViewscreenControlCore_drawCardsList();
});

$("#Viewscreen-Control-Core_currentCardTextbox").on("change",function(event){
	var card = event.target.value - 1;
	setDatabaseValue("viewscreen.forceToTacticalCard",card);
	event.target.value = ViewscreenControlCore_CurrentCard;
});