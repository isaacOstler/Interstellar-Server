var sensorScansCore_internalScanInfo = null;
var sensorScanCore_internalScanAnnounced = false;
var sensorScanCore_internalScanWarningInterval = undefined;
var sensorScansCore_internalScanAnswer = "";
var sensorScansCore_ScanTypeSelected = "internal"; //case sensitive, be careful!
/*
	internal scanInfo object =
	{
		"timePassed" : 0,
		"timeRequired" : 100,
		"scanQuerry" : "intruders",
		"scanLocation" : "all decks",
		"scanType" : "light scan"
	}
	*/
$("#Sensor-Scans-Core_UserPrefences").click(function(event){
	if($("#Sensor-Scans-Core-UserPrefsWindow").css("display") == "block"){
		closeCoreWindow("Sensor-Scans-Core-UserPrefsWindow",event)
	}else{
	interstellarDropDownMenu("password","PLEASE ENTER THE ADMIN PASSWORD",function(enteredData){
		getAdminPassword(function(password){
			if(enteredData == password){
				openCoreWindow("Sensor-Scans-Core-UserPrefsWindow",event);
				}
			});
		});
	}
});

	onDatabaseValueChange("internalSensors.scanAnswer",function(newData){
		if(newData == null){
			setDatabaseValue("internalSensors.scanAnswer", "");
			return;
		}
		sensorScansCore_internalScanAnswer = newData;
		$("#Sensor-ScansCore_ScanAnswerTextarea").val(sensorScansCore_internalScanAnswer);
	})

	$("#Sensor-Scans-Core_SendAnswerButton").click(function(event){
		if($("#Sensor-ScansCore_ScanAnswerTextarea").val() == null){
			$("#Sensor-ScansCore_ScanAnswerTextarea").css("backgroundColor","red");
			return;
		}else{
			$("#Sensor-ScansCore_ScanAnswerTextarea").css("backgroundColor","#ffe6a3");
		}
		sensorScansCore_internalScanAnswer = $("#Sensor-ScansCore_ScanAnswerTextarea").val();
		setDatabaseValue("internalSensors.scanAnswer",sensorScansCore_internalScanAnswer);
	});

	onDatabaseValueChange("internalSensors.scanSpeedBoost",function(newData){
		if(newData == null){
			setDatabaseValue("internalSensors.scanSpeedBoost",1);
			return;
		}
		$("#Sensor-Scans-Core_SpeedTextbox").val(newData + "x");
	})

	$("#Sensor-Scans-Core_ScanProgress").click(function(event){
		if(sensorScansCore_internalScanInfo == null){
			return;
		}
		var newProgress = event.offsetX / $(event.target).width();
		sensorScansCore_internalScanInfo.timePassed = newProgress * sensorScansCore_internalScanInfo.timeRequired;
		setDatabaseValue("internalSensors.scanInfo",sensorScansCore_internalScanInfo);
	});

	$("#Sensor-Scans-Core_InternalSensorsProgress").click(function(event){
		if(sensorScansCore_internalScanInfo == null){
			return;
		}
		var newProgress = event.offsetX / $(event.target).width();
		sensorScansCore_internalScanInfo.timePassed = newProgress * sensorScansCore_internalScanInfo.timeRequired;
		setDatabaseValue("internalSensors.scanInfo",sensorScansCore_internalScanInfo);
	});

	onDatabaseValueChange("internalSensors.scanInfo",function(newData){
		sensorScansCore_internalScanInfo = newData;
		sensor_Scans_Core_UpdateBasedOnScanType();
		if(newData == null){
			sensorScanCore_internalScanAnnounced = false;
			$("#Sensor-Scans-Core_InternalSensorsProgressFill").css("width","0%");
			$("#Sensor-Scans-Core_InternalSensorsProgressLabel").html("INTERNAL SCAN PROGRESS (0%)");
			return;
		}
		if(sensorScansCore_internalScanInfo.timePassed >= sensorScansCore_internalScanInfo.timeRequired && sensorScansCore_internalScanAnswer == ""){
			interstellarSay("SCAN IS PENDING ANSWER!");
		}
		if(newData == "canceled"){
			interstellarSay("INTERNAL SCAN CANCELED");
			$("#Sensor-Scans-Core_InternalSensorsProgressFill").css("width","0%");
			$("#Sensor-Scans-Core_InternalSensorsProgressLabel").html("INTERNAL SCAN PROGRESS (0%)");
			setDatabaseValue("internalSensors.scanInfo",null);
			sensorScanCore_internalScanAnnounced = false;
			if(sensorScansCore_ScanTypeSelected == "internal"){
				$("#Sensor-Scans-Core_ScanQuerry").prepend("(CANCELED)");
			}
			return;
		}
		if(!sensorScanCore_internalScanAnnounced){
			interstellarSay("NEW INTERNAL SCAN");
			sensorScanCore_internalScanAnnounced = true;
		}

		var progress = (newData.timePassed / newData.timeRequired) * 100;
		$("#Sensor-Scans-Core_InternalSensorsProgressFill").css("width",progress + "%");
		$("#Sensor-Scans-Core_InternalSensorsProgressLabel").html("INTERNAL SCAN PROGRESS (" + Math.floor(progress) + "%)");
	//$("#shipScanner").css("left",(((timePassed / timeRequired) - .01) * 100) + "%");
	//$("#progressBarFill").css("width",(100 * (timePassed / timeRequired)) + "%");
	//$("#progressBarText").html(Math.floor(timePassed) + " SECONDS PASSED, " + Math.floor(timeRequired - timePassed) + " SECONDS REMAINING (" + Math.floor((100 * (timePassed / timeRequired))) + "% COMPLETE)");
});

	$("#Sensor-Scans-Core_InstantFinishButton").click(function(event){
		if(sensorScansCore_ScanTypeSelected == "internal"){
			if(sensorScansCore_internalScanInfo != null){
				sensorScansCore_internalScanInfo.timePassed = sensorScansCore_internalScanInfo.timeRequired;
				setDatabaseValue("internalSensors.scanInfo",sensorScansCore_internalScanInfo);
			}
		}
	});

	function sensor_Scans_Core_UpdateBasedOnScanType(){
		var scanProgress = 0;
		var scanMessage = "";
		if(sensorScansCore_ScanTypeSelected == "internal"){
			if(sensorScansCore_internalScanInfo == null){
				$("#Sensor-Scans-Core_ScanQuerry").html("NO INTERNAL SCAN");
				$("#Sensor-Scans-Core_ScanLocation").html("");
				$("#Sensor-Scans-Core_ScanType").html("");
				$("#Sensor-Scans-Core_ScanType").css("backgroundColor","");
				$("#Sensor-Scans-Core_ScanQuerry").css("backgroundColor","");
				$("#Sensor-Scans-Core_ScanProgressFill").css("width","0%");
				$("#Sensor-Scans-Core_ScanProgressLabel").html("NO SCAN IN PROGRESS");
				return;
			}else{
				scanProgress = sensorScansCore_internalScanInfo.timePassed / sensorScansCore_internalScanInfo.timeRequired;
				scanMessage = Math.floor(sensorScansCore_internalScanInfo.timePassed) + "/" + Math.floor(sensorScansCore_internalScanInfo.timeRequired) + " SECONDS PASSED - " + Math.floor(scanProgress * 100) + "% COMPLETE";
				$("#Sensor-Scans-Core_ScanQuerry").html(sensorScansCore_internalScanInfo.scanQuerry);
				$("#Sensor-Scans-Core_ScanLocation").html(sensorScansCore_internalScanInfo.scanLocation);
				$("#Sensor-Scans-Core_ScanType").html(sensorScansCore_internalScanInfo.scanType);
				switch(sensorScansCore_internalScanInfo.scanType){
					case "QUICK SCAN":
					$("#Sensor-Scans-Core_ScanType").css("backgroundColor","#b7b7b7");
					break;
					case "NORMAL SCAN":
					$("#Sensor-Scans-Core_ScanType").css("backgroundColor","#fff832");
					break;
					case "DEEP SCAN":
					$("#Sensor-Scans-Core_ScanType").css("backgroundColor","rgb(255, 166, 50)");
					break;
					default:
					$("#Sensor-Scans-Core_ScanType").css("backgroundColor","");
					break;
				}
				$("#Sensor-Scans-Core_InternalScansButton").css("backgroundColor","#a53636");
			}

			if(sensorScansCore_internalScanInfo != null && sensorScansCore_internalScanAnswer == ""){
				$("#Sensor-Scans-Core_InternalSensorsProgressFill").css("backgroundColor","red");
				$("#Sensor-Scans-Core_ScanQuerry").css("backgroundColor","red");
				$("#Sensor-Scans-Core_ScanProgressFill").css("backgroundColor","red");
				if(scanProgress > .6){
					if(sensorScanCore_internalScanWarningInterval == undefined){
						sensorScanCore_internalScanWarningInterval = setInterval(function(){
							if($("#Sensor-Scans-Core_ScanProgressFill").css('opacity') == .1){
								$("#Sensor-Scans-Core_InternalSensorsProgressFill").animate({opacity : 1},0740);
								$("#Sensor-Scans-Core_ScanProgressFill").animate({opacity : 1},0740);
							}else{
								$("#Sensor-Scans-Core_InternalSensorsProgressFill").animate({opacity : .1},0740);
								$("#Sensor-Scans-Core_ScanProgressFill").animate({opacity : .1},0740);
							}
						},0750);
					}
				}
			}else if(sensorScansCore_internalScanInfo != null && sensorScansCore_internalScanAnswer != ""){
				$("#Sensor-Scans-Core_InternalSensorsProgressFill").css("backgroundColor","");
				$("#Sensor-Scans-Core_ScanQuerry").css("backgroundColor","yellow");
				$("#Sensor-Scans-Core_ScanProgressFill").css("backgroundColor","");
				if(sensorScanCore_internalScanWarningInterval != undefined){
					clearInterval(sensorScanCore_internalScanWarningInterval);
					sensorScanCore_internalScanWarningInterval = undefined;
				}
			}else{
				$("#Sensor-Scans-Core_InternalSensorsProgressFill").css("backgroundColor","");
				$("#Sensor-Scans-Core_ScanQuerry").css("backgroundColor","");
				$("#Sensor-Scans-Core_ScanProgressFill").css("backgroundColor","");
				if(sensorScanCore_internalScanWarningInterval != undefined){
					clearInterval(sensorScanCore_internalScanWarningInterval);
					$("#Sensor-Scans-Core_InternalSensorsProgressFill").animate({opacity : 1},0740);
					$("#Sensor-Scans-Core_ScanProgressFill").animate({opacity : 1},0740);
					sensorScanCore_internalScanWarningInterval = undefined;
				}
			}
			
			$("#Sensor-Scans-Core_ScanProgressFill").css("width",(scanProgress * 100) + "%");
			$("#Sensor-Scans-Core_ScanProgressLabel").html(scanMessage);
		}
	}
	$("#Sensor-Scans-Core_InternalScansButton").click(function(event){
		event.target.style.backgroundColor = "#9b9b9b";
		$("#Sensor-Scans-Core_ExternalScansButton").css("backgroundColor" , "");
		SensorScansCore_ScanTypeSelected = "internal";
		sensor_Scans_Core_UpdateBasedOnScanType();
	});
	$("#Sensor-Scans-Core_ExternalScansButton").click(function(event){
		SensorScansCore_ScanTypeSelected = "external";
		sensor_Scans_Core_UpdateBasedOnScanType();
		event.target.style.backgroundColor = "#9b9b9b";	
		$("#Sensor-Scans-Core_InternalScansButton").css("backgroundColor" , "");
	});

	$("#Sensor-Scans-Core_AutoSendButton").click(function(event){

	});

	$("#Sensor-Scans-Core_specifyButton").click(function(event){
		$("#Sensor-ScansCore_ScanAnswerTextarea").val("SCAN REQUEST IS TOO VAGUE, PLEASE SPECIFY WHAT YOU WISH TO SCAN FOR");
	});

	$("#Sensor-Scans-Core_unknownButton").click(function(event){
		$("#Sensor-ScansCore_ScanAnswerTextarea").val("REQUEST QUERY IS UNKNOWN AND OR AMBIGUOUS, PLEASE RESTATE.");
	});

	$("#Sensor-Scans-Core_unableToScanButton").click(function(event){
		$("#Sensor-ScansCore_ScanAnswerTextarea").val("SCAN REQUEST IS INVALID, SCAN CANNOT BE COMPLETED");
	});

	$("#Sensor-Scans-Core_NoneDetectedButton").click(function(event){
		$("#Sensor-ScansCore_ScanAnswerTextarea").val("NONE DETECTED");
	});